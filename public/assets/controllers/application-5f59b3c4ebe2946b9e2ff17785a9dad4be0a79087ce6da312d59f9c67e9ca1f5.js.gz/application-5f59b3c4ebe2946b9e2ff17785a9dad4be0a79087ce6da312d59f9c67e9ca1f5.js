import {Application} from "@hotwired/stimulus"

// const application = Application.start()
const application = Application

//application.debug = true
//window.Stimulus = application

export {application};
